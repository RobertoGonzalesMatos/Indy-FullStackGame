package indy;

import indy.PlatformPackage.SeparationPlat;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.util.Duration;

public class BlockAni {
    private Image imagePlayer1;
    private final ImageView myImageView;
    private ImageView smallImageView;
    private boolean moveRight = false;
    private int rightCounter;
    private boolean moveLeft = false;
    private int leftCounter;
    private boolean moveDown = false;
    private double downCounter;
    private boolean moveUp = false;
    private double upCounter;
    private int baseY;
    private boolean smallMoveRight = false;
    private int smallRightCounter;
    private boolean smallMoveLeft = false;
    private int smallLeftCounter;
    private boolean smallMoveDown = false;
    private double smallDownCounter;
    private boolean smallMoveUp = false;
    private double smallUpCounter;
    private int smallBaseY;
    private int counter;
    private boolean separation = false;
    private boolean smallState = false;
    /**
     * This is the constructor of the AnimationClass.
     */
    public BlockAni(Pane pane, Player player) {
        this.imagePlayer1 =new Image(getClass().getResourceAsStream("ImagesAndSounds/BigPlayer.png"));
        this.myImageView =new ImageView();
        this.myImageView.setImage(this.imagePlayer1);
        this.setUpImage(player);
        pane.getChildren().add(this.myImageView);
    }
    /**
     * This sets up the image for the Player in the Big State.
     */
    public void setUpImage(Player player) {
        this.myImageView.setScaleX(0.1);
        this.myImageView.setScaleY(0.1);
        this.myImageView.setX(player.getX()-247);
        this.myImageView.setY(player.getY()-225);
    }
    /**
     * This sets the base point for the Y axis for the parabola.
     */
    public void setBaseY(Player player, boolean move) {
        if(!move) {
                this.baseY=player.getY();
        }
    }
    /**
     * This sets the base point for the Y axis for the parabola for the small block.
     */
    public void setSmallBaseY(SmallPlayer smallPlayer, boolean move) {
        if(!move) {
            this.smallBaseY=smallPlayer.getY();
        }
    }
    /**
     * Method that enables the move right Animation.
     */
    public void setMoveRight(Player player, SmallPlayer smallPlayer) {
        if(player!=null) {
            setBaseY(player, this.moveRight);
            this.moveRight=true;
        }
        if(smallPlayer!=null) {
            setSmallBaseY(smallPlayer,this.smallMoveRight);
            this.smallMoveRight =true;
        }
    }
    /**
     * Method that enables the move left Animation.
     */
    public void setMoveLeft(Player player, SmallPlayer smallPlayer) {
        if(player!=null) {
            setBaseY(player, this.moveLeft);
            this.moveLeft=true;
        }
        if(smallPlayer!=null) {
            setSmallBaseY(smallPlayer,this.smallMoveLeft);
            this.smallMoveLeft =true;
        }
    }
    /**
     * Method that enables the move down Animation.
     */
    public void setMoveDown(Player player, SmallPlayer smallPlayer) {
        if(player!=null) {
            setBaseY(player, this.moveDown);
            this.moveDown=true;
        }
        if(smallPlayer!=null) {
            setSmallBaseY(smallPlayer,this.smallMoveDown);
            this.smallMoveDown =true;
        }
    }
    /**
     * Method that enables the move up Animation.
     */
    public void setMoveUp(Player player, SmallPlayer smallPlayer) {
        if(player!=null) {
            setBaseY(player, this.moveUp);
            this.moveUp=true;
        }
        if(smallPlayer!=null) {
            setSmallBaseY(smallPlayer,this.smallMoveUp);
            this.smallMoveUp =true;
        }
    }
    /**
     * Move right animation for the big player
     */
    public void rightAni() {
        if(this.moveRight&&!(this.rightCounter >=84)) {
            aniMove(1, ((0.0119*(this.rightCounter)*(this.rightCounter)-
                    (this.rightCounter))-149+(this.baseY-75)));
            this.rightCounter +=1;
        } else if (this.rightCounter <=84) {
            this.rightCounter =0;
            this.moveRight=false;
        }
    }
    /**
     * Move right animation for the big small
     */
    public void smallRightAni() {
        if(this.smallMoveRight &&!(this.smallRightCounter >=84)) {
            smallAniMove(1, ((0.0119*(this.smallRightCounter)*(this.smallRightCounter)-
                    (this.smallRightCounter))-149+(this.smallBaseY -75)));
            this.smallRightCounter +=1;
        } else if (this.smallRightCounter <=84) {
            this.smallRightCounter =0;
            this.smallMoveRight =false;
        }
    }
    /**
     * Move left animation for the big player
     */
    public void leftAni(){
        if(this.moveLeft&&!(this.leftCounter >=84)) {
            aniMove(-1, ((0.0119*(this.leftCounter)*(this.leftCounter))-(this.leftCounter))-
                    149+(this.baseY-75));
            this.leftCounter +=1;
        } else if (leftCounter <=84){
            this.leftCounter =0;
            this.moveLeft=false;
        }
    }
    /**
     * Move left animation for the small player
     */
    public void smallLeftAni() {
        if(this.smallMoveLeft &&!(this.smallLeftCounter >=84)) {
            smallAniMove(-1, ((0.0119*(this.smallLeftCounter)*(this.smallLeftCounter))-
                    (this.smallLeftCounter))-149+(this.smallBaseY -75));
            this.smallLeftCounter +=1;
        } else if (smallLeftCounter <=84) {
            this.smallLeftCounter =0;
            this.smallMoveLeft =false;
        }
    }
    /**
     * Move up animation for the big player
     */
    public void upAni() {
        if(this.moveUp&&!(this.upCounter >=41)) {
            aniMove(-0.5, (int) ((0.07647*(this.upCounter -10)*(this.upCounter -10))-
                    2.355*(this.upCounter -10))-182+(this.baseY-75));
            this.upCounter +=0.5;
        } else if (upCounter <=41) {
            this.upCounter =0;
            this.moveUp=false;
        }
    }
    /**
     * Move up animation for the small player
     */
    public void smallUpAni(){
        if(this.smallMoveUp &&!(this.smallUpCounter >=41)) {
            smallAniMove(-0.5, (int) ((0.07647*(this.smallUpCounter -10)*(this.smallUpCounter -10))-
                    2.355*(this.smallUpCounter -10))-182+(this.smallBaseY -75));
            this.smallUpCounter +=0.5;
        } else if (smallUpCounter <=41) {
            this.smallUpCounter =0;
            this.smallMoveUp =false;
        }
    }
    /**
     * Move down animation for the big player
     */
    public void downAni(){
        if(this.moveDown&&!(this.downCounter >=41)) {
            aniMove(0.5, (int) ((0.07647*(this.downCounter)*(this.downCounter))-
                    2.355*(this.downCounter))-148+(this.baseY-75));
            this.downCounter +=0.5;
        } else if (downCounter <=41) {
            this.downCounter =0;
            this.moveDown=false;
        }
    }
    /**
     * Move down animation for the small player
     */
    public void smallDownAni(){
        if(this.smallMoveDown &&!(this.smallDownCounter >=41)) {
            smallAniMove(0.5, (int)((0.07647*(this.smallDownCounter)*(this.smallDownCounter))-
                    2.355*(this.smallDownCounter))-148+(this.smallBaseY -75));
            this.smallDownCounter +=0.5;
        } else if (smallDownCounter <=41) {
            this.smallDownCounter =0;
            this.smallMoveDown =false;
        }
    }
    /**
     * Method to move the player image
     */
    public void aniMove(double x, double y) {
        this.myImageView.setX(this.myImageView.getX()+x);
        this.myImageView.setY(y);
    }
    /**
     * Method to move the player image
     */
    public void smallAniMove(double x, double y) {
        this.smallImageView.setX(this.smallImageView.getX()+x);
        this.smallImageView.setY(y);
    }
    /**
     * Timeline for the animations
     */
    public void aniTimeline(Player player, SmallPlayer smallPlayer, Pane pane) {
        KeyFrame blockTimeline = new KeyFrame(Duration.seconds(0.005), (ActionEvent) -> {
            /**
             * Trigger the separation image method after a certain amount of time
             */
            if(!this.smallState && SeparationPlat.intersects(player,0,0, Color.ORANGE)){
                this.separation =true;
            }
            if(separation) {
                this.counter++;
                if(counter>=84) {
                    this.separation =false;
                    this.counter=0;
                    pane.getChildren().remove(myImageView);
                    this.setUpDivision(pane,player,smallPlayer);
                }
            }
            this.rightAni();
            this.leftAni();
            this.downAni();
            this.upAni();
            this.smallRightAni();
            this.smallLeftAni();
            this.smallDownAni();
            this.smallUpAni();
        });
        Timeline timeline = new Timeline(blockTimeline);
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
    }
    /**
     * Method set the player image back to the big State
     */
    public void aniReAppear(Player player, Pane pane) {
        pane.getChildren().removeAll(myImageView, smallImageView);
        this.imagePlayer1 =new Image(getClass().getResourceAsStream("ImagesAndSounds/BigPlayer.png"));
        this.myImageView.setImage(this.imagePlayer1);
        this.setUpImage(player);
        pane.getChildren().add(this.myImageView);
        this.rightCounter =84;
        this.leftCounter =84;
        this.downCounter =41;
        this.upCounter =41;
    }
    /**
     * Method to set up the image for the small state
     */
    public void smallSetUpImage(Player player,SmallPlayer smallPlayer) {
        this.smallImageView.setScaleX(0.05);
        this.smallImageView.setScaleY(0.05);
        this.smallImageView.setX(smallPlayer.getX()-247);
        this.smallImageView.setY(smallPlayer.getY()-225);
        this.myImageView.setScaleX(0.05);
        this.myImageView.setScaleY(0.05);
        this.myImageView.setX(player.getX()-247);
        this.myImageView.setY(player.getY()-225);
    }
    /**
     * Getter method for the smallState boolean
     */
    public void getSmallState(boolean smallBlock) {
        this.smallState = smallBlock;
    }
    /**
     * Falling animation
     */
    public void fallState() {
        this.myImageView.setY(this.myImageView.getY()+20);
        this.myImageView.toBack();
    }
    /**
     * Method that sets up the change between the big and small player
     */
    public void setUpDivision(Pane blockPane, Player player, SmallPlayer smallPlayer){
        this.imagePlayer1 = new Image(getClass().getResourceAsStream(
                "ImagesAndSounds/SmallPlayer.png"));
        this.myImageView.setImage(this.imagePlayer1);
        blockPane.getChildren().add(this.myImageView);

        Image imagePlayer2 = new Image(getClass().getResourceAsStream(
                "ImagesAndSounds/SmallPlayer.png"));
        this.smallImageView =new ImageView();
        this.smallImageView.setImage(imagePlayer2);
        blockPane.getChildren().add(this.smallImageView);
        this.smallSetUpImage(player,smallPlayer);
    }
    /**
     * Method to remove the player image.
     */
    public void removeAni(Pane blockPane) {
        if(smallState) {
            blockPane.getChildren().remove(smallImageView);
        }
        blockPane.getChildren().remove(myImageView);
    }
}
