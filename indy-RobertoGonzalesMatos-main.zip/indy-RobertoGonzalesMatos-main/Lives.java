package indy;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
public class Lives {
    /**
     * Constructor for the lives that the player has
     */
    public Lives (Pane blockPane, int numberOfLives) {
        for (int i=0; i<numberOfLives;i++) {
            Image heartImage = new Image(getClass().getResourceAsStream("ImagesAndSounds/HeartPixel.png"));
            ImageView myImageView = new ImageView();
            myImageView.setImage(heartImage);
            myImageView.setScaleX(0.2);
            myImageView.setScaleY(0.2);
            blockPane.getChildren().add(myImageView);
            myImageView.setX(i*60-100);
            myImageView.setY(370);
        }
    }
}
