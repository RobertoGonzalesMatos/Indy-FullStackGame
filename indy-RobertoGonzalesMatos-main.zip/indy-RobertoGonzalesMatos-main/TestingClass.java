package indy;

import indy.PlatformPackage.Board;
import org.junit.Test;

public class TestingClass {
    /**
     * Constructor for the testing class
     */
    public TestingClass (){}
    Board map;
    /**
     * Test for the shuffle key method
     */
    @Test
    public void Test1(){
        map=new Board();
        Queue queue = map.shuffleKeys(5);
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
    }
}
