package indy;

import javafx.scene.paint.Color;

public class SmallPlayer extends Player {
    /**
     * Constructor that sets up the small player
     */
    public SmallPlayer() {
        super();
        this.setX(-50, 0, 0);
        this.setY(-50, 0, 0);
        this.changeFill(Color.GREEN, Color.LIMEGREEN, Color.DARKGREEN);
    }
}
