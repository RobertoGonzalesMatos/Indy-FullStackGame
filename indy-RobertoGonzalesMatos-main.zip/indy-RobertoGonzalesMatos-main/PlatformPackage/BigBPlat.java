package indy.PlatformPackage;

import indy.Player;
import javafx.scene.paint.Color;

public class BigBPlat extends Platforms {
    /**
     * Constructor for the BigBlockPlat class
     */
    public BigBPlat() {
        super();
        this.setFill(Color.BLUE);
    }
    /**
     * Method that restrains movement to the small player
     */
    public static boolean canMove(Player player, int x, int y) {
        int col = (player.getX() - 25-((player.getY()-75)*41)/32) / 84+x;
        int row = (player.getY() - 75) / 32  + y;
        return (col != -1 && !(row == -1 | col == 10) && row != 10) &&
                !Board.platCheck(row, col, Color.DARKBLUE,true);
    }
    /**
     * Method that changes the color of the platform when the player is able to use it
     */
    @Override
    public void lightUp(boolean smallState) {
        if(!smallState) {
            this.setFill(Color.BLUE);
        } else {
            this.setFill(Color.DARKBLUE);
        }
    }
}
