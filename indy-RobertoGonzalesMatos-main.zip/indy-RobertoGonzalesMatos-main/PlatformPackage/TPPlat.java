package indy.PlatformPackage;

import indy.BlockAni;
import indy.Player;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class TPPlat extends Platforms {
    private static int preX;
    private static int preY;
    /**
     * Constructor for the Teleportation platform
     */
    public TPPlat() {
        super();
        this.setFill(Color.GOLD);
    }
    /**
     * Method that checks the direction that the player is coming from
     */
    public static boolean direction(Player player, int x, int y) {
        int col = (player.getX() - 25-((player.getY()-75)*41)/32) / 84+x;
        int row = (player.getY() - 75) / 32  + y;
        return !(col <= -1) && !(row <= -1) && !(col >= 10) && !(row >= 10)
                && Board.platCheck(row, col, Color.GOLD, false);
    }
    /**
     * Method that registers the direction of the player
     */
    public static void registerDirection(Player player) {
        if(direction(player, 1,0)) {
            preX=84;
            preY=0;
        }
        if(direction(player,-1,0)) {
            preX=-84;
            preY=0;
        }
        if(direction(player,0,1)) {
            preX=41;
            preY=32;
        }
        if(direction(player,0,-1)) {
            preX=-41;
            preY=-32;
        }
    }
    /**
     * Method that teleports the player two spaces ahead from the platform
     * taking into consideration the direction that it came from.
     */
    public static void teleport(Player player, BlockAni image, Pane pane, boolean SmallState) {
        if(!SmallState&& direction(player,0,0)) {
            player.move(2*preX,2*preY);
            image.aniReAppear(player,pane);
        }
    }
}
