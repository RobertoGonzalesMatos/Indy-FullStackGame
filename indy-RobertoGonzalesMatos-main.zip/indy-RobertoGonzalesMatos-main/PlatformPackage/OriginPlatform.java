package indy.PlatformPackage;


import indy.BlockAni;
import indy.Player;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class OriginPlatform extends Platforms{
    /**
     * Constructor for originPlatoform class
     */
    public OriginPlatform (){
        super();
        this.setFill(Color.LIGHTSTEELBLUE);
    }
    /**
     * Method that checks if the player is in the origin platform
     */
    public static Boolean originCheck(Player player) {
        int col = (player.getX() - 25- (player.getY() - 75)) / 84;
        int row = (player.getY() - 75) / 32;
        return (!(col <= -1) && !(row <= -1) && !(col >= 10) && !(row >= 10)) &&
                Board.platCheck(row, col, Color.LIGHTSTEELBLUE, false);
    }
    /**
     * Method that returns the player to the origin
     */
    public static void returnOrigin(Player player, BlockAni playerImage, Pane pane) {
        if(originCheck(player)) {
            player.reEnablePlayer();
            playerImage.aniReAppear(player,pane);
        }
    }
}
