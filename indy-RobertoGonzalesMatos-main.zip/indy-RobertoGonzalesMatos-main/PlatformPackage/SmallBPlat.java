package indy.PlatformPackage;

import indy.Player;
import javafx.scene.paint.Color;

public class SmallBPlat extends Platforms {
    /**
     * Constructor for the SmallBlockPlat class
     */
    public SmallBPlat() {
        super();
        this.setFill(Color.GREEN);
    }
    /**
     * Method that restrains movement to the Big player
     */
    public static boolean canMove(Player player, int x, int y) {
        int col = (player.getX() - 25-((player.getY()-75)*41)/32) / 84 + x;
        int row = (player.getY() - 75) / 32  + y;
        return col <= -1 || row <= -1 || col >= 10 || row >= 10 ||
                !Board.platCheck(row, col, Color.DARKGREEN, false);
    }
    /**
     * Method that changes the color of the platform when the player is able to use it
     */
    @Override
    public void lightUp(boolean smallState) {
        if(smallState) {
            this.setFill(Color.rgb(0,200,0));
        } else {
            this.setFill(Color.DARKGREEN);
        }
    }
}
