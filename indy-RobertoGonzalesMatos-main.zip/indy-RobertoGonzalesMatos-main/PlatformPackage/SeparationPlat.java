package indy.PlatformPackage;

import indy.Player;
import indy.SmallPlayer;
import javafx.scene.paint.Color;

public class SeparationPlat extends Platforms {
    private static int sBX=0;
    private static int sBY=0;
    private static int BBX=0;
    private static int BBY=0;
    /**
     * Constructor for the separation platform
     */
    public SeparationPlat() {
        super();
        this.setFill(Color.ORANGE);
    }
    /**
     * Method that changes the state of the player
     */
    public static boolean stateChange(Player player, Boolean bigState) {
        int col = (player.getX() - 25-((player.getY()-75)*41)/32) / 84;
        int row = (player.getY() - 75) / 32;
        if (Board.platCheck(row, col,Color.ORANGE, false)) {
            return true;
        }
        return bigState;
    }
    /**
     * Method to check if the player intersects with the platform
     */
    public static boolean intersects(Player player, int x, int y, Color color) {
        int col = (player.getX() - 25-((player.getY()-75)*41)/32) / 84 + x;
        int row = (player.getY() - 75) / 32  + y;
        return !(col <= -1 || row <= -1 | col >= 10 || row >= 10)
                && Board.platCheck(row, col, color, false);
    }
    /**
     * Method that checks available spaces and places the small blocks on the available ones.
     */
    public static void smartSeparationMethod(Player player, SmallPlayer smallPlayer) {
        if(SeparationPlat.intersects(player,0,0,Color.ORANGE)) {
            resetValue();
            for (int i = 1; i<9;i++) {
                switch(i){
                case 1:
                    clockWiseChecker(player,-41,-32,0,-1);
                case 2:
                    clockWiseChecker(player,43,-32,1,-1);
                case 3:
                    clockWiseChecker(player,84,0,1,0);
                case 4:
                    clockWiseChecker(player,125,32,1,1);
                case 5:
                    clockWiseChecker(player,41,32,0,1);
                case 6:
                    clockWiseChecker(player,-43,32,-1,1);
                case 7:
                    clockWiseChecker(player,-84,0,-1,0);
                case 8:
                    clockWiseChecker(player,-125,-32,-1,-1);
                }
            }
            player.setX(BBX,0,0);
            player.setY(BBY,0,0);
            smallPlayer.setX(sBX,0,0);
            smallPlayer.setY(sBY,0,0);
        }
    }
    /**
     * Method that determines if a platform is available and give the coordinates for the small platform
     * to be placed there. If one other platform is available then one of the small players will be placed
     * in the separation platform itself. The coordinates are checked in a clockwise manner for both small
     * blocks but the original player will be placed in the first available platform in a clockwise manner,
     * while the other one will be placed down in a counterclockwise manner.
     */
    public static void clockWiseChecker(Player player, int offsetX, int offsetY,int offsetRow, int offsetCol) {
        if(sBX==0&&sBY==0&&SeparationPlat.intersects(player,offsetRow,offsetCol,Color.MEDIUMVIOLETRED)) {
            sBX=player.getX()+ offsetX;
            sBY=player.getY()+ offsetY;
        } else if (!(sBX==0&&sBY==0)&&SeparationPlat.intersects(player,offsetRow,offsetCol,Color.MEDIUMVIOLETRED)) {
            if(sBX==player.getX()+ offsetX&&sBY==player.getY()+ offsetY) {
                BBX=player.getX();
                BBY=player.getY();
            } else {
                BBX=player.getX()+ offsetX;
                BBY=player.getY()+ offsetY;
            }
        }
    }
    /**
     * Method that resets the values of the coordinates for the separation method.
     */
    public static void resetValue() {
        sBX=0;
        sBY=0;
    }
}
