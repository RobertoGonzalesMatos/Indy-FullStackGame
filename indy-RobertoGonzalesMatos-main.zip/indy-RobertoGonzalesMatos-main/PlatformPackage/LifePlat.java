package indy.PlatformPackage;


import indy.App;
import indy.Player;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import java.util.ArrayList;

public class LifePlat extends Platforms {
    private static final ArrayList<Integer> liveXArray=new ArrayList<>();
    private static final ArrayList<Integer> liveYArray=new ArrayList<>();
    private static ImageView imageView;
    /**
     * Constructor for the LifePlatform class
     */
    public LifePlat() {
        super();
        this.setFill(Color.LIGHTCORAL);
    }
    /**
     * Method that records the X and Y coordinates of the platforms that have been used
     */
    public static void storeXY(Player player) {
       liveXArray.add(player.getX());
       liveYArray.add(player.getY());
    }
    /**
     * Method that checks if the platform has already been used
     */
    public static int checkArray(Player player, int nlife, Pane pane) {
        if(liveIntersects(player)&& liveXArray.isEmpty()){
            storeXY(player);
            pane.getChildren().remove(imageView);
            nlife++;
        } else {
            for (int i = 1; i< liveXArray.size()+1; i++) {
                if(liveIntersects(player)&&!liveXArray.contains(player.getX())&&!liveYArray.contains(player.getY())) {
                    storeXY(player);
                    pane.getChildren().remove(imageView);
                    nlife++;
                }
            }
        }
        return nlife;
    }
    /**
     * Method that checks if the platform is intersecting with the player
     */
    public static boolean liveIntersects(Player player) {
        int col = (player.getX() - 25-((player.getY()-75)*41)/32) / 84;
        int row = (player.getY() - 75) / 32;
        return (row != -1 && col != -1 && row != 10 && col != 10) &&
                Board.platCheck(row, col, Color.LIGHTCORAL, false);
    }
    /**
     * Method that clears the Arraylists with the coordinates of the used platforms
     */
    public static void clearLiveArray() {
        liveXArray.clear();
        liveYArray.clear();
    }
    /**
     * Method that puts a heart on platforms that haven't been used by the player
     */
    public static void heartSetUp(Pane pane, int x, int y) {
        if(!liveXArray.contains(x+96)&&!liveYArray.contains(y-32)) {
            Image life = new Image(App.class.getResourceAsStream("ImagesAndSounds/HeartPixel.png"));
            imageView=new ImageView();
            imageView.setImage(life);
            imageView.setScaleX(0.1);
            imageView.setScaleY(0.1);
            pane.getChildren().add(imageView);
            imageView.setX(x);
            imageView.setY(y);
            imageView.toFront();
        }
    }
}
